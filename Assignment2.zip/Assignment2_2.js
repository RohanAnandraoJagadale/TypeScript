// write a typescript program which contains one function named as Summation . that function accepts array of numbers and returns the summation of each number from aaray
// Input : 23 6 7 4 5 7
// Output : Addition is 52
function Addition(Arr) {
    var Cnt = 0;
    var Sum = 0;
    for (Cnt; Cnt < Arr.length; Cnt++) {
        Sum = Sum + Arr[Cnt];
    }
    return Sum;
}
var Add = [23, 6, 7, 4, 5, 7];
var Ret = 0;
Ret = Addition(Add);
console.log("Addition of numbers is : " + Ret);
