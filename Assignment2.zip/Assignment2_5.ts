// Write a typescript program which contains one function named as ChkString . That function accepts one string and check whether that string contains "Marvellous" word or not
// Input : "Pune Kothrud Marvellous Infosystems"
// Output : String contains Marvellous in it.

function ChkString(str : string) : boolean
{
    if(str.indexOf('Marvellous') >= 0)
    {
        return true
    }
    else
    {
        return false
    }
}

var strr : string = "Pune Kothrud Marvellous Infosystems"

var Ret : boolean = false

Ret = ChkString(strr)

if(Ret == true)
{
    console.log("String contains Marvellous in it")
}
else
{
    console.log("String can not contains Marvellous in it.")
}