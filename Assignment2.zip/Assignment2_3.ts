// Write a typescript program which contains one function named as Maximum . That function accepts array of numbers and returns the second largest number fromarray
// Input : 23 89 6 29 56 45 77 32
// Output : Maximum number is 89

function Maximum(Arr : number[]) : number
{
    var Second_Highest = Arr.sort(function(a,b) {return b-a;}) [1]
    return Second_Highest
}

var SMax : number[] = [23,89,6,29,56,45,77,32]

var Ret : number = 0

Ret = Maximum(SMax)

console.log("Maximum number is : "+Ret)