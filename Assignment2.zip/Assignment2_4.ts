// Write a typescript program which contains one arrow function named as ChkArmstrong. That function accepts one numbers and check whether number is Armstrong number or not.
// Input = 153
// Output : It is Armstrong number


function ChkArmstrong(No : number ): boolean
{
    var DigCnt : number = 0
    var Temp : number = No
    var Digit : number = 0

    var Cnt : number = 0
    var Power : number = 1
    var Sum : number = 0

    while(Temp != 0)
    {
        DigCnt++
        Temp = Temp/10
    }

    Temp = No

    while(Temp != 0)
    {
        Digit = Temp % 10

        for(Cnt = 1; Cnt <= DigCnt; Cnt++)
        {
            Power = Power * Digit

        }
        Sum = Sum + Power
        Power = 1

        Temp = Temp/10
    }

    if(Sum == No)
    {
        return true
    }
    else
    {
        return false
    }
}

var Value : number = 153

var Ret : boolean 

Ret = ChkArmstrong(Value)

if(Ret == true)
{
    console.log("it is a Armstrong number")
}
else
{
    console.log("it is not a Armstrong number")
}