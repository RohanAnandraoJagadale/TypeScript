// Write a typescript program which contains one function named as Maximum . That function accepts array of numbers and returns the second largest number fromarray
// Input : 23 89 6 29 56 45 77 32
// Output : Maximum number is 89
function Maximum(Arr) {
    var second_Highest = Arr.sort(function (a, b) { return b - a; })[1];
    return second_Highest;
}
var SMax = [23, 89, 6, 29, 56, 45, 77, 32];
var Ret = 0;
Ret = Maximum(SMax);
console.log("Maximum number is : " + Ret);
