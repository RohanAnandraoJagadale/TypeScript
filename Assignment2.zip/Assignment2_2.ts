// write a typescript program which contains one function named as Summation . that function accepts array of numbers and returns the summation of each number from aaray
// Input : 23 6 7 4 5 7
// Output : Addition is 52

function Addition(Arr : number[]) : number
{
    var Cnt : number = 0

    var Sum : number = 0

    for(Cnt ; Cnt < Arr.length ; Cnt++)
    {
        Sum = Sum + Arr[Cnt]
    }
    return Sum
}

var Add : number[] = [23,6,7,4,5,7]

var Ret : number = 0

Ret = Addition(Add)

console.log("Addition of numbers is : "+Ret)