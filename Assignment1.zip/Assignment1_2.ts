// ite a TypeScript program which contains one function one function named as area. That function should calculate area of circle. Accept value of radius from user and return its area. Default value of PI should be 3.14 if it is not provided by the caller.
// Input = 5
// Output = Area of circle is : 78.5
function Area(Rad : number) : number
{
    var PI : number = 3.14
    var Area : number = 0

    Area = PI*(Rad*Rad)

    return Area
}

var Radius : number = 5

var Ret : number = 0

Ret = Area(Radius)

console.log("Area of Circle is : "+Ret)
