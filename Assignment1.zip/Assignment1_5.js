// Write a typescript program which contains one function named as Fibonacci. That function accepts one number from user and print Fibonacci series till that number.
// Input : 21
// Output : 1 1 2 3 5 8 13 21
function Fibonacci(No1) {
    var Cnt = 1;
    var A = 0;
    var B = 1;
    var Fib = 0;
    for (Cnt; Cnt < No1; ++Cnt) {
        var Fib_1 = A + B;
        A = B;
        B = Fib_1;
        console.log(B);
        if (Fib_1 == No1) {
            break;
        }
    }
}
var Value = 21;
Fibonacci(Value);
