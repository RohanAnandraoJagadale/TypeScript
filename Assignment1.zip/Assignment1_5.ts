// Write a typescript program which contains one function named as Fibonacci. That function accepts one number from user and print Fibonacci series till that number.
// Input : 21
// Output : 1 1 2 3 5 8 13 21

function Fibonacci(No1 : number): void
{
    var Cnt : number = 1
    var A : number = 0
    var B : number = 1
    var Fib : number = 0
    for(Cnt; Cnt < No1; ++Cnt)
    {
        const Fib = A + B
        A = B
        B = Fib
        console.log(B)

        if(Fib == No1)
        {
            break
        }
    }
}

var Value : number = 21

Fibonacci(Value)