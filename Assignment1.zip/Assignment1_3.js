// Write a typescript program which contains one function named as DisplayFactors . That function should accept one number and display factors of that number
// Input : 20
// Output : 1 2 4 5 10
function DisplayFactors(No1) {
    var Cnt = 1;
    for (Cnt; Cnt <= (No1 / 2); Cnt++) {
        if (No1 % Cnt == 0) {
            console.log(Cnt);
        }
    }
}
var Value = 20;
DisplayFactors(Value);
