// Write a typeScript program which contains one function named as ChkPrime . That function should accept one number and it should  return true if the given number is prime and otherwise return false .
// Input : 11
// Output : It is a prime number.

function ChkPrime(No1 : number) : boolean
{
    var Cnt : number = 1

    for(Cnt ; Cnt <= (No1 -1); Cnt++)
    {
        if(No1 % 2 == 0)
        {
            return false
        }
        else
        {
            return true
        }
    }
}

var Value : number = 11

var Ret : boolean = false

Ret = ChkPrime(Value)

if(Ret == true)
{
    console.log("It is a prime number")
}
else
{
    console.log("It is not a Prime Number")
}