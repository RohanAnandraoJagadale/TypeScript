// Create one typescript application which contains one class named as Circle.
// Circle class contains two characteristics (Class data members) as Radius , PI.
// Create one parametrised constructor which accepts one value and assign it to Radius . Value of PI member is set to 3.14.
// In Circle class we have to one method (Behaviours) as Area which will return area of circle.
// After designing the class create two objects of that class by providing some hardcoded value.
// Call Circumference and Area methods by using both the objects.
var Circle = /** @class */ (function () {
    function Circle(Data) {
        this.Radius = Data;
        this.PI = 3.14;
    }
    Circle.prototype.Area = function () {
        var Ans = 0;
        Ans = this.PI * this.Radius * this.Radius;
        return Ans;
    };
    return Circle;
}());
var Ret = 0;
var obj1 = new Circle(15);
Ret = obj1.Area();
console.log("Area is : " + Ret);
var obj2 = new Circle(20);
Ret = obj2.Area();
console.log("Area is : " + Ret);
