// Create one typescript application which contains one class named as Arithmetic .
// Arithmetic class contains three characteristics (Class data members) as Number1, Number2.
// Create one parametrised constructor which accepts two values and assign it to Number1 and Number2.
// In Arithmetic class we have to write four methods (Behaviours ) as Addition , substraction , multiplication and division 
// Addition method will add Number1, Number2, & return result
// Substraction method will substract Number1, Number2 & return result.
// Multiplication method will multiply Number!, Number2 & return result.
// Division method will divide Number1, Number2 & return result.
// After designing the class create two objkects of that class by providing some hardcoded value.
// Call all the methods by using both the objects.

class Arithmetic
{
    Number1 : number
    Number2 : number

    constructor(No1 : number, No2 : number)
    {
        this.Number1 = No1
        this.Number2 = No2
    }

    Addition() : number
    {
        let Ans : number = 0

        Ans = this.Number1 + this.Number2

        return Ans
    }

    Substraction() : number
    {
        let Ans : number = 0

        Ans = this.Number1-this.Number2

        return Ans
    }

    Multiplication() : number
    {
        let Ans : number = 0

        Ans = this.Number1*this.Number2

        return Ans
    }

    Division() : number
    {
        let Ans : number = 0

        Ans = this.Number1/this.Number2

        return Ans
    }
}

var Ret : number = 0

var obj1 = new Arithmetic(11,10)
Ret = obj1.Addition()
console.log("Addition is : "+Ret)

var obj1 = new Arithmetic(11,10)
Ret = obj1.Substraction()
console.log("Substraction is : "+Ret)

var obj1 = new Arithmetic(11,10)
Ret = obj1.Multiplication()
console.log("Multiplication is : "+Ret)

var obj1 = new Arithmetic(11,10)
Ret = obj1.Division()
console.log("Division is : "+Ret)