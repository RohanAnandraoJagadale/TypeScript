// Create one typescript application which contains one class named as CircleX which inherits above Circle class.
// In CircleX class we have to write one method (Behaviours) as Circumference which will return circumference of circle.
// After designing the class create two objects of that class by providing some hardcoded value.
// Call Circumference and Area methods by using both the objects.

class Circle
{
    Radius : number
    PI : number

    constructor(Data : number)
    {
        this.Radius = Data
        this.PI = 3.14
    }

    Area() : number
    {
        let Ans : number = 0
        Ans = this.PI * this.Radius * this.Radius
        return Ans
    }
}

class CircleX extends Circle
{
    constructor(Data : number)
    {
        super(Data)
    }

    Circumfarance() : number
    {
        let Ans : number = 0
        Ans = 2 * this.PI*this.Radius
        return Ans
    }
}

var Ret : number = 0

var obj1 = new CircleX(15)

Ret = obj1.Area()
console.log("Area is : "+Ret)

Ret = obj1.Circumfarance()
console.log("Circumfarance is : "+Ret)
console.log()

var obj2 = new CircleX(20)

Ret = obj2.Area()
console.log("Area is : "+Ret)

Ret = obj2.Circumfarance()
console.log("Circumfarance is : "+Ret)
console.log()